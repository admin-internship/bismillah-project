<?php
$con = mysqli_connect('localhost','root','', '#namadb');	//conn database
if(!$con){
		die('could not connect; '.mysqli_error());
		}
?>